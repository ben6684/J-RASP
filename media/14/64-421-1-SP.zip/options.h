#ifndef __OPTIONS_H__
#define __OPTIONS_H__

typedef struct sO {

  int nOptions;
  char ** key;
  char ** value;

} sOptions;

sOptions *   newOptions     (char **argv, int argc);
void         deleteOptions  (sOptions *O);

int          getIntOption   (const sOptions * O, 
                             const char *key, int defaultValue);
double       getDoubleOption(const sOptions * O, 
                             const char *key, double defaultValue);
const char * getStringOption(const sOptions * O, 
                             const char *key, const char * defaultValue);

#endif
