/*Copyright (C) 2012, Laurent Oudre <laurent.oudre@cmla.ens-cachan.fr>
This program is free software: you can use, modify and/or
redistribute it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 3 of the License, or (at your option) any later
version. You should have received a copy of this license along
this program. If not, see <http://www.gnu.org/licenses/>.*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>
#define PI 3.14159265

#ifndef isfinite
# define isfinite(x) ((x) * 0 == 0)
#endif

/*Create vector x (int) of size N witih zero values*/
int * zeros_ivect(int N){
int * x=NULL;
int i=0;

    x=malloc(N*sizeof(int));
        if (x == NULL)
    {
        printf("Allocation is impossible");
        exit(EXIT_FAILURE);
    }
    #pragma omp parallel for private(i)
    for (i=0;i<N;i++){
        x[i]=0;
    }

    return x;

}

/*Create vector x (double) of size N with zero values*/
double * zeros_dvect(int N){
double * x=NULL;
int i=0;

    x=malloc(N*sizeof(double));
        if (x == NULL) {
        printf("Allocation is impossible");
        exit(EXIT_FAILURE);
        }

    #pragma omp parallel for private(i)
    for (i=0;i<N;i++){
        x[i]=0.0;
    }

    return x;

}

/*Create matrix x (double) of size MxN with zero values*/
double ** zeros_dmat(int M,int N){

    double *bloc, **x;
    int i=0;
    x= malloc( M * sizeof(double*));
    bloc=malloc(sizeof(double)*N*M);
        if (x == NULL) {
        printf("Allocation is impossible");
        exit(EXIT_FAILURE);
        }

    #pragma omp parallel for private(i)
    for (i=0;i<N*M;i++) {
        bloc[i]=0.0;
    }
    for( i = 0 ; i < M ; i++ ) {
     x[i] = &bloc[i*N];
        if (x[i] == NULL) {
        printf("Allocation is impossible");
        exit(EXIT_FAILURE);
        }
    }
    return x;
}


/*Generate an integer randomly chosen between n_start and n_end*/
int irand(int n_start,int n_end){

return (int)(n_start + rand() / (double)RAND_MAX * (n_end- n_start + 1));

}

/*Generate a sample from a Gaussian of mean mu and standard deviation sigma*/
double randn(double mu,double sigma)
{
    double U,V=0;
	U = (rand() + 1.) / (RAND_MAX + 2.);
    V = rand() / (RAND_MAX + 1.);

    return mu + sigma*sqrt(-2 * log(U)) * sin(2 * PI * V);
}







void rand_unique(int debut,int fin,int nombre,int ** vect_rand){

    int i=0;
    int j=0;
    int randomValue=0;
    int dejaTire=1;


    if (nombre>fin-debut+1) {
        printf("Impossible");
        exit(0);
    }

    *vect_rand=realloc(*vect_rand,nombre * sizeof(int));	
    (*vect_rand)[0]=(int)(debut + rand() / (double)RAND_MAX * (fin - debut + 1));

    if (nombre>1) {

    for (i=1;i<nombre;i++) {

                dejaTire=1;
        while (dejaTire==1) {
            randomValue = (int)(debut + rand() / (double)RAND_MAX * (fin - debut + 1));
            (*vect_rand)[i]=randomValue;
            dejaTire=0;
                for (j=0;j<i;j++) {
                    if ((*vect_rand)[j]==randomValue) {
                        dejaTire=1;
                        break;
                    }
                }
        }

    }
    }
return ;

}







/* Sort vector x in ascending order */
void isort(int * x, int N) {
int i=0;
int tmp=0;
int flag=1;

while (flag==1) {

flag =0;
for (i =0; i < N-1; i++) {
	if (x[i]>x[i+1]) {
	tmp=x[i+1];
	x[i+1]=x[i];
	x[i]=tmp;
	flag=1;
	}
}
}
}

/*Print vector x (int) of size N*/
void    print_ivect(int *x, int N){
    int i=0;
    for (i=0;i<N;i++) {
        printf("%i\n",x[i]);
    }

    return;
}


/*Print vector x (double) of size N*/
void    print_dvect(double *x, int N){
    int i=0;
    for (i=0;i<N;i++) {
        printf("%f\n",x[i]);
    }

    return;
}

/*Print matrix X (double) of size MxN*/
void    print_dmat(double **x, int M,int N){
    int i,j=0;
    for (i=0;i<M;i++) {
        for (j=0;j<N;j++) {
            printf("%f ",x[i][j]);
        }
    printf("\n");
    }

    return;
}

/*Return the sum of vector x between sample i_min and i_max*/
int   sum_ivect(int *x,int i_min,int i_max,int N){

    int value=0;
    int i=0;

    if (i_min<0 || i_max>N) {
        printf("Indexes are out of range");
        exit(EXIT_FAILURE);
        return 0;
    }

    for (i=i_min;i<i_max;i++) {
        value+=x[i];
    }

    return value;
}

/* Return the dot product between vectors x and y*/
double   dot_dvect(double *x,int i_minx,int i_maxx,int Nx,double *y,int i_miny,int i_maxy, int Ny){

    int N=0;
    double value=0;
    int i=0;

    if (i_minx<0 || i_maxx>Nx-1 || i_miny<0 || i_maxy>Ny-1) {
        printf("Indexes are out of range");
        exit(EXIT_FAILURE);
        return 0;
    }

    N=i_maxx-i_minx+1;

    if (i_maxy-i_miny+1!=N) {
        printf("Dot product is impossible : both vectors have not the same size");
        exit(EXIT_FAILURE);
        return 0;
    }

    for (i=0;i<N;i++){
         value+=x[i+i_minx]*y[i+i_miny];
    }

    return value;

}


/* Return the L1 norm between vectors x and y*/
double   maxl1norm_dvect(double *x,int i_minx,int i_maxx,int Nx,double *y,int i_miny,int i_maxy, int Ny){

    int N=0;
    double value=0;
    int i=0;

    if (i_minx<0 || i_maxx>Nx-1 || i_miny<0 || i_maxy>Ny-1) {
        printf("Indexes are out of range");
        exit(EXIT_FAILURE);
        return 0;
    }

    N=i_maxx-i_minx+1;

    if (i_maxy-i_miny+1!=N) {
        printf("Dot product is impossible : both vectors have not the same size");
        exit(EXIT_FAILURE);
        return 0;
    }

    for (i=0;i<N;i++){
	if (fabs(x[i+i_minx]-y[i+i_miny])>value)
         value=fabs(x[i+i_minx]-y[i+i_miny]);
    }

    return value;

}


/* Return the absolute value of the maximum of vectors x and y*/
double   maxabs_dvect(double *x,int i_minx,int i_maxx,int Nx,double *y,int i_miny,int i_maxy, int Ny){

    int N=0;
    double value=0;
    int i=0;

    if (i_minx<0 || i_maxx>Nx-1 || i_miny<0 || i_maxy>Ny-1) {
        printf("Indexes are out of range");
        exit(EXIT_FAILURE);
        return 0;
    }

    N=i_maxx-i_minx+1;

    if (i_maxy-i_miny+1!=N) {
        printf("Dot product is impossible : both vectors have not the same size");
        exit(EXIT_FAILURE);
        return 0;
    }

    for (i=0;i<N;i++){
	if (fabs(x[i+i_minx])>value)
         value=fabs(x[i+i_minx]);

	if (fabs(y[i+i_miny])>value)
	 value=fabs(y[i+i_miny]);
    }

    return value;

}








/*Return 1 if value is present in x, 0 otherwise*/
int ispresent(int value,int * x,int N) {

int i_current,i_start,i_end;

if ((value<x[0])||(value>x[N-1]))
    return 0;

i_current=0;
i_start=0;
i_end=N-1;

 while (i_start <=i_end)
{

i_current=(i_end+i_start)/2;

if (x[i_current]==value)
{
return 1;
}

if (value<x[i_current])
{
i_end= i_current-1;
}

if (value>x[i_current])
{
i_start=i_current+1;
}

}

return 0;
}















int isdefined (double * x, int N) {

int i,flag=1;

for (i=0;i<N;i++) {
    if (!isfinite(x[i])) {
        flag=0;
        break;
    }

}
return flag;
}



int find_first(int * x, int i_min, int i_max, int N) {

int i;

if (i_max>N) {
        printf("Indexes are out of range");
        exit(EXIT_FAILURE);
        return 0;
}

for (i=i_min;i<i_max;i++) {
    if (x[i]!=0) {
        break;
    }
}

if (i!=i_max) {
return i;
}
else return -1;

}
