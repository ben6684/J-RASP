#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "sound.h"

#define	BLOCK_SIZE 512

void soundResize(Sound *S, long n); /*Prototype de soundResize */

Sound * audioRead(const char * infile, long n1, long n2)
{
  SNDFILE *f;

  double * buf;  /* for working */ 
  int k, m, readcount, blocksize ;
  long toPass, toRead, nSamples;

  Sound *S = (Sound *) malloc(sizeof(Sound));
  S->nChannels = 0;
  S->nSamples = 0L;
  S->channel = NULL;
  S->sampleRate = 0;
  S->Nbit=0;

  if (n2 == -1L) n2 = 100000000L;

  if (n1 >= n2) 
     {
	strcpy(S->errMsg, "error (audioRead): "
	       "n1 >= n2");
	return S;
      }      

  S->_sfinfo.format = 0;

    /* sf_open is a function of SNDFILE */
    f = sf_open(infile, SFM_READ, &(S->_sfinfo));
    S->sampleRate = S->_sfinfo.samplerate;

    if (f) 
      { 
	S->nChannels = S->_sfinfo.channels;
	strcpy(S->errMsg, "");
      }
    else 
      {
	strcpy(S->errMsg, "error (audioRead): "
	       "Sound input file cannot be opened");
	return S;
      }      
  
  buf = (double *) malloc(S->nChannels*BLOCK_SIZE*sizeof(double)) ;
  
  nSamples = n2 - n1 + 1;

  soundResize(S, 1000L);
  
  /* The n1th file sample is the first signal sample, 
     we pass the n1-1 first file samples */
  toPass = n1-1;
  blocksize = toPass > BLOCK_SIZE ? BLOCK_SIZE : toPass;
  
  while ((readcount = sf_readf_double (f, buf, blocksize)) > 0) {
    toPass -= readcount;
    blocksize = toPass > BLOCK_SIZE ? BLOCK_SIZE : toPass;
  }
  
  toRead = nSamples;
  blocksize = toRead > BLOCK_SIZE ? BLOCK_SIZE : toRead;
  
  while ((readcount = sf_readf_double (f, buf, blocksize)) > 0) 
    {
      long iSample = nSamples - toRead;
 
      if (iSample + readcount > S->nSamples)
	soundResize(S, 2*S->nSamples);

      for (m=0; m<readcount; m++, iSample++) {
	for (k=0; k <S->nChannels; k++) {
	  S->channel[k][iSample] = buf[k + S->nChannels * m];
	}
      }
      toRead -= readcount;
      blocksize = toRead > BLOCK_SIZE ? BLOCK_SIZE : toRead;
    }

  soundResize(S, nSamples - toRead);  
  S->start = n1;
  free(buf);

  sf_close (f); 
  
  return S;

}

void audioWrite(Sound *S, const char * outfile)
{
  SNDFILE *f;

  double * buf;
  int k, m, writecount, blocksize ;
  long toWrite;
  long iSample;

  SF_INFO *p = &(S->_sfinfo);
  f = sf_open(outfile, SFM_WRITE, p);
  if (f) {
      strcpy(S->errMsg, "");
  }
  else {
    strcpy(S->errMsg, "error (audioWrite): "
	   "Sound output file cannot be opened");
    return;
  } 

  buf = (double *) malloc(sizeof(double) * S->nChannels * BLOCK_SIZE);
  toWrite = S->nSamples;
  blocksize = toWrite > BLOCK_SIZE 
    ? BLOCK_SIZE 
    : toWrite;
  
  iSample = 0;
  while (toWrite > 0) {

    for (m=0; m<blocksize; m++, iSample++) {
      for (k=0; k <S->nChannels; k++) {
        buf[k + S->nChannels * m] = S->channel[k][iSample];
      }
    }
    writecount = sf_writef_double (f, buf, blocksize);
    if (writecount < blocksize) {
      strcpy(S->errMsg, "error (audioWrite): "
             "Cannot write all samples");
      return;
    }
    toWrite -= writecount;
    blocksize = toWrite > BLOCK_SIZE 
      ? BLOCK_SIZE 
      : toWrite;
  }
  free(buf);
  sf_close (f);
}
         

/* /////////////////////////////////////////////////////

///////// ??????????????????????  /////////
///////// ??????????????????????  /////////

/////////////////////////////////////////////////////  */
void soundResize(Sound *S, long n)/* Corps de soundResize */
{
  long size = sizeof(double) * S->nChannels * n, smin;
  double *v = (double *) malloc(size);
  double **w = (double **) malloc(sizeof(double *) * S->nChannels);
  long i;
  int k;

  for (k=0; k<S->nChannels; k++)
      w[k] = v + k * n;

  smin = (n < S->nSamples) ? n : S->nSamples;

  for (k=0; k<S->nChannels; k++) {
    for (i=0; i<smin; i++)
        w[k][i] = S->channel[k][i];
    for (; i<n; i++) w[k][i] = 0.0; 
  }
  S->nSamples = n;
  if (S->channel) {
     free(S->channel[0]);
     free(S->channel);
  }
  S->channel = w;
}

void soundClean(Sound *S)
{
  if (S->channel) {
    free(S->channel[0]);
    free(S->channel);
  }
  free(S);
}

Sound * audioReadText(const char *fileName)
{
   FILE * f = fopen(fileName, "r");
   long i, n = 0, n0 = -1L;
   long nmax = 1000;
   double v;
   /* double *x = alloc(double, nmax); */
   double *x = (double *) malloc(nmax*sizeof(double));
   /* memoire dynamique  */
   /*  malloc(nmax*sizeof(double)) est un pointeur sur nmax*sizeof(double) bytes (char) */
   /* (double *) transform en un pointeur sur  nmax doubles*/


  Sound *S = (Sound *) malloc(sizeof(Sound));
  S->nChannels = 0;
  S->nSamples = 0L;
  S->channel = NULL;
  S->sampleRate = 0;
  S->Nbit=0;

   S->nChannels = 1; /* 1 canal */

   /* while (1) "tout le temps vrai, boucle infini" */

   n = 0L; 
   while (1) {
     int err = fscanf(f, "%ld %lg", &i, &v);
     if (err < 2) break;
     if (n0 < 0) n0 = i;
     if (feof(f)) break;
     if (n>=nmax) {
       double *x_new = alloc(double, 2*nmax);
       memcpy(x_new, x, nmax*sizeof(double));
       free(x);
       x = x_new;
       nmax *= 2;
     }
     x[n] = v;
     n++;
   }
   fprintf(stderr, "n = %ld\n", n);
 
   soundResize(S, n);
   for (i=0; i<n; i++)
      S->channel[0][i] = x[i];

   free(x); 
   fclose(f);
   S->start = n0;
   return S;
}

void audioWriteText(const Sound *S, const char *fileName)
{
  FILE *f = fopen(fileName, "w");
  long i, n = S->nSamples;
  long k, kmax = S->nChannels;
 
  for (i=0; i<n; i++) {
    fprintf(f, "%6ld", i + S->start); 
    for (k=0; k<kmax; k++) {
      fprintf(f, " %12.7g", S->channel[k][i]);
      }
    fprintf(f, "\n");
  }
  fclose(f);
}







