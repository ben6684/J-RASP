#ifndef _SOUND_H_
#define _SOUND_H_

#include <sndfile.h>
#include <stdlib.h>

#define alloc(T, n) (T *) malloc((n)*sizeof(T))

typedef struct _Sound {

  SF_INFO _sfinfo;

  double ** channel;
  long nChannels;
  long nSamples;
  long start;
  int sampleRate;
  int Nbit;

  char errMsg[1000];  /* memore statique (pas dynamique) */

} Sound;

void soundClean(Sound *S);

Sound * audioRead(const char * infile, long n1, long n2);
void audioWrite(Sound *S, const char * outfile);

void audioWriteText(const Sound *S, const char *fileName);
Sound * audioReadText(const char *fileName);


#endif
