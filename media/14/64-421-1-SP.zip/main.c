#include <stdio.h>
#include <stdlib.h>
#include <sndfile.h>
#include <math.h>
#include <time.h>
#include <omp.h>

#include    "sound.h"
#include    "basics.h"
#include    "options.h"
#include    "functions.h"

int main(int argc, char **argv)
{

/* DECLARATION OF THE VARIABLES */

/* Inputs */
const char
    * inSound = NULL, /*Path to the input audio file*/
    * outSound=NULL; /*Path to the output restored audio file*/


double K=0; /* First threshold*/
int p=0, /* Order of the model*/
    b=0, /* Second threshold*/
    nWindow=0; /*Window length*/



/*Internal variables*/
sOptions *O=NULL;
int    i=0;

Sound 	* S=NULL;

int * burst1=NULL,
    * burst2=NULL;

double nSamples=0;

/* READING AND SETTING THE INPUT PARAMETERS */

/* Read the input parameters */
  inSound = argc > 1 ? argv[1] : NULL;
  if (inSound == NULL) return -1;
  O = newOptions(argv + 1, argc-1);

/* Default values for the input parameters */
K    = getDoubleOption(O, "K",   2.0);
b    = getIntOption(O, "b",   20);
p    = getIntOption(O, "p",   3*100+2);
nWindow    = getIntOption(O, "nWindow",   8*p);


outSound = getStringOption(O, "outSound", NULL);

/* MAIN FUNCTION */
srand (time (NULL));

/* Reading the input sound signal*/
S=audioRead(inSound,1,20000000);

printf("K=%.2f b=%d p=%d Nw=%d ",K,b,p,nWindow);


/* Iteration 1*/
burst1=zeros_ivect(S->nSamples);
reconstruct_signal(S,p,K,b,nWindow,burst1);

/* Iteration 2*/
burst2=zeros_ivect(S->nSamples);
reconstruct_signal(S,p,K,b,nWindow,burst2);

/* Calculation of the total number of samples detected as noise */
for (i=0;i<S->nSamples;i++) {
	if ((burst2[i]==1)||(burst1[i]==1)) {
	nSamples=nSamples+1;
	}
}

nSamples=100*nSamples/((double) S->nSamples);
nSamples=floor(100*nSamples)/100;
printf(" - Percentage of samples detected as noise : %.2f\n",nSamples);


if (outSound)
    audioWrite(S,outSound);




soundClean(S);
free(burst1);
free(burst2);
deleteOptions(O);

return 0;

}
