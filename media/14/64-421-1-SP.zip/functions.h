#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED

void reconstruct_signal(Sound * S,int p, double K, int b, int nWindow, int * burst);
double update_a(double * y,int p,int nWindow,double * a);
void update_x(double * y, int p, double * a, int * t, int m, double * x);
void solve_Cholesky(double ** A, double * x, int N);
#endif
