/*Copyright (C) 2012, Laurent Oudre <laurent.oudre@cmla.ens-cachan.fr>
This program is free software: you can use, modify and/or
redistribute it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 3 of the License, or (at your option) any later
version. You should have received a copy of this license along
this program. If not, see <http://www.gnu.org/licenses/>.*/

#include <sndfile.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <omp.h>

#include    "sound.h"
#include    "functions.h"
#include    "basics.h"

#define PI 3.14159265

void reconstruct_signal(Sound * S,int p, double K, int b, int nWindow, int * burst) {

int N,nHop,nFrames,i,j,k,m,first,last;
double  * input_zeropad,
	* output_zeropad,
	* w,
	* y,
	* a,
	* x,
	* d;
int * t,
    * i_t,
    * burst_zeropad;

double sigmae;
N=S->nSamples;
nHop=nWindow/4;
nFrames=floor((N+nWindow)/nHop)+1;

i=0;
j=0;
k=0;
first=0;
last=0;
sigmae=0;

/* Zero-padded versions of the audio signal and of the burst*/
input_zeropad=zeros_dvect(nWindow+(nFrames-1)*nHop);
output_zeropad=zeros_dvect(nWindow+(nFrames-1)*nHop);
burst_zeropad=zeros_ivect(nWindow+(nFrames-1)*nHop);
#pragma omp parallel for private(i) shared(input_zeropad)
for (i=0;i<N;i++) {
    input_zeropad[i+nWindow]=S->channel[0][i];
}

/* Hamming window of size nWindow */
w=zeros_dvect(nWindow);
#pragma omp parallel for private(i) shared(w) 
for (i=0;i<nWindow;i++) {
    w[i]=(0.54-0.46*cos(2*PI*i/nWindow))/(4*0.54);
}


y=NULL;
a=NULL;
t=NULL;
x=NULL;
d=NULL;
i_t=NULL;
m=0; /* Number of missing samples on frame i */

#pragma omp parallel for private(y,d,x,t,a,j,k,m,i_t,first,last,sigmae) shared(input_zeropad,w,output_zeropad,burst_zeropad)
for (i=0;i<nFrames;i++) {

y=zeros_dvect(nWindow);
i_t=zeros_ivect(nWindow);
d=zeros_dvect(nWindow);
a=zeros_dvect(p+1);
t=NULL;
x=NULL;
m=0;
j=0;
k=0;
sigmae=0;
first=0;
last=0;

    for (j=0;j<nWindow;j++) {
        y[j]=input_zeropad[i*nHop+j];
    }

    sigmae=update_a(y,p,nWindow,a);

    if (isdefined(a,p+1)) {

        for (j=p;j<nWindow;j++) {
                for (k=0;k<p+1;k++) {
                    d[j]+=a[k]*y[j-k];
                }
        }

        for (j=0;j<nWindow;j++) {
            if (fabs(d[j])>K*sigmae) {
                i_t[j]=1;
                }
        }
        m=sum_ivect(i_t,0,nWindow,nWindow);


        if (m>0) {
            first=find_first(i_t,0,nWindow,nWindow);
            while ((first<nWindow-1)&(last!=-1)) {
                last=find_first(i_t,first+1,nWindow,nWindow);
                if ((last-first>1)&(last-first<=b)&(last!=-1)) {
                    for (j=first;j<last;j++) {
                        i_t[j]=1;
                    }
                }
            first=last;
            }

            for (j=0;j<p;j++) {
                i_t[j]=0;
            }
            for (j=nWindow-p;j<nWindow;j++) {
                i_t[j]=0;
            }
            m=sum_ivect(i_t,0,nWindow,nWindow);


            if (m>0) {
            t=realloc(t,m*sizeof(int)); /* Indexes of the missing samples on frame i */
            x=realloc(x,m*sizeof(double)); /* Interpolated samples on frame i */

                /* Determination of the indexes of the missing samples on frame i
                 (The first and last p samples are not considered)*/
                k=0;
                for (j=p;j<nWindow-p;j++) {
                    if (i_t[j]==1) {
                        t[k]=j;
                        k++;
                    }
                }

                update_x(y,p,a,t,m,x);



                for (j=0;j<m;j++) {
                    y[t[j]]=x[j];
                }




            }

        }
    }

    if (sum_ivect(i_t,0,nWindow,nWindow)>0) {
        for (j=0;j<nWindow;j++) {
                if (i_t[j]==1)
                    burst_zeropad[i*nHop+j]=1;
        }
    }

    for (j=0;j<nWindow;j++) {
        output_zeropad[i*nHop+j]+=y[j]*w[j];
    }

free(x);
free(t);
free(d);
free(y);
free(a);
free(i_t);

}


#pragma omp parallel for private(i) shared(S,output_zeropad)
for (i=0;i<N;i++) {
   S->channel[0][i]=output_zeropad[i+nWindow];
}
for (i=0;i<N;i++) {
   burst[i]=burst_zeropad[i+nWindow];
}

free(w);
free(input_zeropad);
free(output_zeropad);
free(burst_zeropad);

}

/* ESTIMATE THE AR PARAMETERS (LEVINSON ALGORITHM) */
double update_a(double * y,int p,int nWindow,double * a) {

double *R =zeros_dvect(p+1);
double *a_old=zeros_dvect(p);
double sigma2=0;
double k=0;
int i,j=0;

#pragma omp parallel for private(i) shared(R,y)
for (i=0;i<p+1;i++) {
    R[i]=dot_dvect(y,i,nWindow-1,nWindow,y,0,nWindow-i-1,nWindow)/nWindow;
}


/* Levinson algorithm */

/*Initizalization*/
a_old[0]=-R[1]/R[0];
sigma2=(1-a_old[0]*a_old[0])*R[0];
a[0]=a_old[0];

for (j=1;j<p;j++) {
    /* Calculation of the reflection coeff */
    k=0;
    for (i=0;i<j;i++) {
        k+=a_old[i]*R[j-i];
    }
    k=(R[j+1]+k)/sigma2;

    /*Update*/
    a[j]=-k;
    sigma2=(1-a[j]*a[j])*sigma2;
    for (i=j-1;i>=0;i--) {
        a[i]=a_old[i]+a[j]*a_old[j-i-1];
   }

    for (i=0;i<j+1;i++) {
    a_old[i]=a[i];
    }
}

a[0]=1;
for (i=0;i<p;i++) {
    a[i+1]=a_old[i];
}

free(a_old);
free(R);
return sqrt(sigma2);

}


/* RECONSTRUCT THE MISSING SAMPLES*/
void update_x(double * y, int p, double * a, int * t, int m, double * x) {

double * b=zeros_dvect(p+1);
double **B=zeros_dmat(m,m);
int i,j=0;

for (i=0;i<p+1;i++) {
    b[i]=dot_dvect(a,0,p-i,p+1,a,i,p,p+1);
}

for (i=0;i<m;i++) {
    for (j=i;j<m;j++) {
            if (abs(t[i]-t[j])<p+1) {
                B[i][j]=b[abs(t[i]-t[j])];
                B[j][i]=B[i][j];
            }
    }
}


 for (i=0;i<m;i++) {
     x[i]=0;
     for (j=-p;j<p+1;j++) {
            if (ispresent(t[i]-j,t,m)==0)
            {
                x[i]+=b[abs(j)]*y[t[i]-j];
            }
     }
 }

for (i=0;i<m;i++) {
    x[i]=-x[i];
}


solve_Cholesky(B,x,m);

free(*B);
free(B);
free(b);

return;

}


/* SOLVE THE MATRIX EQUATION Ax=y through Cholesky decomposition*/
void solve_Cholesky(double ** A, double * x, int N) {

/*STEP 1 : Decomposition of A as L'DL where :
- L is a lower triangular matrix
- D is a diagonal matrix
*/

double ** L=zeros_dmat(N,N);
double *  d=zeros_dvect(N);
double *  v=zeros_dvect(N);


int i,j=0;

for (j=0;j<N;j++) {
    if (j>0) {
        for (i=0;i<j;i++) {
            v[i]=L[j][i]*d[i];
        }
        v[j]=A[j][j]-dot_dvect(L[j],0,j-1,N,v,0,j-1,N);
    }
    else {
        v[j]=A[j][j];
    }
    d[j]=v[j];

    if (v[j]==0) {
        printf("Singular Matrix %d",j);
        exit(EXIT_FAILURE);
        return;
    }

    if (j<N-1) {
        for (i=j+1;i<N;i++) {
            L[i][j]=(A[i][j]-dot_dvect(L[i],0,j-1,N,v,0,j-1,N))/v[j];

        }
    }

L[j][j]=1;
}

for (i=0;i<N;i++) {
    for (j=0;j<i+1;j++) {
        L[j][i]=L[i][j];
    }
}



/* STEP 2 : Solving two traingular systems*/
for (i=0;i<N;i++) {
    v[i]=0;
}

for (i=0;i<N;i++) {
    v[i]=(x[i]-dot_dvect(L[i],0,i,N,v,0,i,N));
}

for (i=0;i<N;i++) {
    x[i]=0;
}

for (i=N-1;i>-1;i--) {
    x[i]=(v[i]/d[i]-dot_dvect(L[i],i,N-1,N,x,i,N-1,N));
}


free(*L);
free(L);
free(v);
free(d);

return;


}

