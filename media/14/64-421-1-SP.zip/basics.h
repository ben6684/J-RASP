#ifndef BASICS_H_INCLUDED
#define BASICS_H_INCLUDED


int *       zeros_ivect(int N);
double *    zeros_dvect(int N);

double **    zeros_dmat(int M,int N);

void    print_ivect(int *x, int N);
void    print_dvect(double *x, int N);
void    print_dmat(double **x, int M,int N);

int         sum_ivect(int *x,int i_min,int i_max,int N);

int irand(int n_start,int n_end);
void isort(int * x, int N);
double randn(double mu,double sigma);
void rand_unique(int debut,int fin,int nombre,int ** vect_rand);

double   dot_dvect(double *x,int i_minx,int i_maxx,int Nx,double *y,int i_miny,int i_maxy, int Ny);
double   maxl1norm_dvect(double *x,int i_minx,int i_maxx,int Nx,double *y,int i_miny,int i_maxy, int Ny);
double   maxabs_dvect(double *x,int i_minx,int i_maxx,int Nx,double *y,int i_miny,int i_maxy, int Ny);

int ispresent(int value,int * x,int N);
int isdefined (double * x, int N);

int find_first(int * x, int i_min, int i_max, int N);


#endif
