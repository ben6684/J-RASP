#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "options.h"

sOptions * newOptions(char **argv, int argc)
{
  sOptions * O;
  int i, nOptions, iOptions;

  nOptions = 0;
  for (i=0; i<argc; i++) {
    if (strchr(argv[i], '=') != NULL) nOptions++; 
  }

  O = (sOptions *) malloc(sizeof(sOptions));

  O->nOptions = nOptions;
  if (nOptions == 0) {
    O->key = NULL;
    O->value = NULL;
  }
  else {
    O->key = (char **) malloc(sizeof(char *) * nOptions);
    O->value = (char **) malloc(sizeof(char *) * nOptions);
    iOptions = 0;
    for (i=0; i<argc; i++) {
      const char * p = strchr(argv[i], '=');
      if (p != NULL) {
        O->key[iOptions] = (char *) malloc(strlen(argv[i])+1);
        strcpy(O->key[iOptions], argv[i]);
        O->key[iOptions][p - argv[i]] = '\0';
        O->value[iOptions] = O->key[iOptions] + (p - argv[i] + 1);
        iOptions++; 
      }
    }
    
  }
  return O;
}

void deleteOptions(sOptions *O)
{
  int i;
  for (i=0; i<O->nOptions; i++)
    free(O->key[i]);

  if (O->key) free(O->key);
  if (O->value) free(O->value);
  free(O);
}


int getIntOption(const sOptions * O, 
                 const char *key, int defaultValue)
{
  int i;
  for (i=0; i<O->nOptions; i++)
    if (strcmp(key, O->key[i]) == 0)
      return atoi(O->value[i]);
  return defaultValue;
}

double getDoubleOption(const sOptions * O, 
                       const char *key, double defaultValue)
{
  int i;
  for (i=0; i<O->nOptions; i++)
    if (strcmp(key, O->key[i]) == 0)
      return atof(O->value[i]);
  return defaultValue;
}

const char * getStringOption(const sOptions * O, 
                             const char *key, const char * defaultValue)
{
  int i;
  for (i=0; i<O->nOptions; i++)
    if (strcmp(key, O->key[i]) == 0)
      return O->value[i];
  return defaultValue;
}

